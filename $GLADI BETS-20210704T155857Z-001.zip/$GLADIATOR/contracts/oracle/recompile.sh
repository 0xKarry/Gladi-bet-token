sudo rm -r -d build
truffle compile
