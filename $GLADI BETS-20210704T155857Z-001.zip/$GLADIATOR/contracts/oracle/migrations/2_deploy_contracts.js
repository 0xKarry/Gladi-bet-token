var BoxingOracle = artifacts.require("BoxingOracle");

module.exports = function(deployer) {
  deployer.deploy(BoxingOracle);
};
